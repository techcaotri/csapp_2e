extern char *optarg;
int getopt(int argc, char *argv[], char *key);
